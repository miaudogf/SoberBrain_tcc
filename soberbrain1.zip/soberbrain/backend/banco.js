const { DatabaseSync } = require("node:sqlite");
const { readFileSync, mkdirSync } = require("node:fs");
const { dirname, join } = require("node:path");
const { randomUUID } = require("node:crypto");

function abrirBanco(arquivo) {
  if (arquivo !== ":memory:") mkdirSync(dirname(arquivo), { recursive: true });
  const db = new DatabaseSync(arquivo);
  db.exec(readFileSync(join(__dirname, "../database/schema.sql"), "utf8"));

  function estado(usuario) {
    const registros = db.prepare(`
      SELECT r.data, r.humor, r.nota, COALESCE(c.situacao, '') AS consumo,
        COALESCE(c.substancia, '') AS substancia, COALESCE(c.quantidade, '') AS quantidade,
        COALESCE(c.contexto, '') AS contexto
      FROM registros r LEFT JOIN registros_consumo c ON c.registro_id = r.id
      WHERE r.usuario_id = ? ORDER BY r.data DESC`).all(usuario.id);
    const porData = new Map(registros.map(registro => {
      registro.atividades = [];
      return [registro.data, registro];
    }));
    const vinculos = db.prepare(`
      SELECT r.data, a.atividade_id FROM registro_atividades a
      JOIN registros r ON r.id = a.registro_id WHERE r.usuario_id = ? ORDER BY a.atividade_id`).all(usuario.id);
    for (const item of vinculos) porData.get(item.data).atividades.push(item.atividade_id);
    const metas = db.prepare("SELECT id, titulo, alvo, progresso FROM metas WHERE usuario_id = ? ORDER BY rowid").all(usuario.id);
    return { perfil: { nome: usuario.nome, email: usuario.email }, registros, metas };
  }

  function salvarRegistro(usuarioId, registro) {
    // Consumo e atividades fazem parte da mesma edição do dia.
    db.exec("BEGIN IMMEDIATE");
    try {
      const { id } = db.prepare(`INSERT INTO registros (usuario_id, data, humor, nota) VALUES (?, ?, ?, ?)
        ON CONFLICT(usuario_id, data) DO UPDATE SET humor = excluded.humor, nota = excluded.nota
        RETURNING id`).get(usuarioId, registro.data, registro.humor, registro.nota);
      db.prepare("DELETE FROM registros_consumo WHERE registro_id = ?").run(id);
      if (registro.consumo) {
        db.prepare("INSERT INTO registros_consumo (registro_id, situacao, substancia, quantidade, contexto) VALUES (?, ?, ?, ?, ?)")
          .run(id, registro.consumo, registro.substancia, registro.quantidade, registro.contexto);
      }
      db.prepare("DELETE FROM registro_atividades WHERE registro_id = ?").run(id);
      const associar = db.prepare("INSERT INTO registro_atividades (registro_id, atividade_id) VALUES (?, ?)");
      for (const atividade of registro.atividades) associar.run(id, atividade);
      db.exec("COMMIT");
    } catch (erro) {
      db.exec("ROLLBACK");
      throw erro;
    }
  }

  function salvarHumor(usuarioId, data, humor) {
    db.prepare(`INSERT INTO registros (usuario_id, data, humor) VALUES (?, ?, ?)
      ON CONFLICT(usuario_id, data) DO UPDATE SET humor = excluded.humor`).run(usuarioId, data, humor);
  }

  function criarMeta(usuarioId, meta) {
    const id = randomUUID();
    db.prepare("INSERT INTO metas (id, usuario_id, titulo, alvo) VALUES (?, ?, ?, ?)").run(id, usuarioId, meta.titulo, meta.alvo);
    return id;
  }
  return { db, estado, salvarRegistro, salvarHumor, criarMeta };
}

module.exports = { abrirBanco };
