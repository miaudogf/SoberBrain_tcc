const http = require("node:http");
const path = require("node:path");
const { readFile } = require("node:fs/promises");
const { abrirBanco } = require("./banco");
const { usarApi, responder, ErroHttp } = require("./api");
const { ErroEntrada } = require("../frontend/js/modelo");

const raiz = path.resolve(__dirname, "../frontend");
const tipos = {
  ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8", ".png": "image/png", ".webp": "image/webp"
};

function criarServidor(arquivo = path.join(__dirname, "dados/soberbrain.sqlite")) {
  const banco = abrirBanco(arquivo);
  const api = usarApi(banco);
  const servidor = http.createServer(async (req, res) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "same-origin");
    try {
      const caminho = new URL(req.url, "http://localhost").pathname;
      if (caminho.startsWith("/api/")) return await api(req, res, caminho);
      if (!["GET", "HEAD"].includes(req.method)) throw new ErroHttp(405, "Método indisponível.");
      const relativo = caminho === "/" ? "index.html" : caminho.slice(1);
      if (!/^[a-zA-Z0-9_./-]+$/.test(relativo) || relativo.split("/").includes("..")) throw new ErroHttp(404, "Arquivo não encontrado.");
      const arquivo = path.resolve(raiz, relativo);
      if (!arquivo.startsWith(raiz + path.sep) || !Object.hasOwn(tipos, path.extname(arquivo))) {
        throw new ErroHttp(404, "Arquivo não encontrado.");
      }
      const conteudo = await readFile(arquivo);
      res.writeHead(200, { "Content-Type": tipos[path.extname(arquivo)] });
      res.end(req.method === "HEAD" ? undefined : conteudo);
    } catch (erro) {
      const status = erro.status || (erro instanceof ErroEntrada ? 422 : ["ENOENT", "EISDIR", "ENOTDIR"].includes(erro.code) ? 404 : 500);
      const mensagem = status === 500 ? "Falha ao concluir a operação." : status === 404 ? "Item não encontrado." : erro.message;
      if (!res.headersSent) responder(res, status, { erro: mensagem });
      else res.end();
    }
  });
  servidor.on("close", () => banco.db.close());
  return servidor;
}

if (require.main === module) {
  const args = process.argv.slice(2);
  function opcao(chave) {
    const i = args.indexOf(chave);
    return i < 0 ? undefined : args[i + 1];
  }
  const host = opcao("--host") || opcao("--hostname") || process.env.HOST || "127.0.0.1";
  const porta = Number(opcao("--port") || process.env.PORT || 3000);
  const servidor = criarServidor(process.env.SOBERBRAIN_DB);
  servidor.listen(porta, host, () => console.log("SoberBrain em http://" + host + ":" + servidor.address().port));
}
module.exports = { criarServidor };
