const { createHash, randomBytes, scrypt, timingSafeEqual } = require("node:crypto");
const { promisify } = require("node:util");
const modelo = require("../frontend/js/modelo");
const derivar = promisify(scrypt);
const diasSessao = 7;

class ErroHttp extends Error {
  constructor(status, mensagem) { super(mensagem); this.status = status; }
}

function responder(res, status, dados) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(dados));
}

async function lerCorpo(req) {
  if (req.headers["x-soberbrain"] !== "1" || req.headers["content-type"]?.split(";")[0] !== "application/json") {
    throw new ErroHttp(415, "Envie dados JSON pela aplicação.");
  }
  const partes = [];
  let tamanho = 0;
  for await (const parte of req) {
    tamanho += parte.length;
    if (tamanho > 16_384) throw new ErroHttp(413, "O formulário ultrapassou o tamanho permitido.");
    partes.push(parte);
  }
  try {
    const dados = JSON.parse(Buffer.concat(partes).toString("utf8"));
    if (!dados || typeof dados !== "object" || Array.isArray(dados)) throw new Error();
    return dados;
  } catch {
    throw new ErroHttp(400, "O formulário precisa conter um objeto JSON válido.");
  }
}

function hash(token) { return createHash("sha256").update(token).digest("hex"); }

function definirCookie(res, valor, idade) {
  const seguro = process.env.COOKIE_SEGURO === "1" ? "; Secure" : "";
  res.setHeader("Set-Cookie", "sb_sessao=" + valor + "; HttpOnly; SameSite=Lax; Path=/; Max-Age=" + idade + seguro);
}

function usarApi(banco) {
  const { db } = banco;
  function iniciarSessao(usuarioId, res, tokenAnterior) {
    const token = randomBytes(32).toString("hex");
    const agora = Date.now();
    db.prepare("DELETE FROM sessoes WHERE expira_em <= ? OR token_hash = ?").run(agora, hash(tokenAnterior));
    db.prepare("INSERT INTO sessoes VALUES (?, ?, ?)").run(hash(token), usuarioId, agora + diasSessao * 86_400_000);
    definirCookie(res, token, diasSessao * 86_400);
  }
  function localizarUsuario(token) {
    return db.prepare(`SELECT u.id, u.nome, u.email FROM sessoes s JOIN usuarios u ON u.id = s.usuario_id
      WHERE s.token_hash = ? AND s.expira_em > ?`).get(hash(token), Date.now());
  }

  return async function api(req, res, caminho) {
    const metodo = req.method;
    const token = (req.headers.cookie || "").match(/(?:^|;\s*)sb_sessao=([a-f0-9]{64})(?:;|$)/)?.[1] || "";
    const usuario = localizarUsuario(token);
    if (caminho === "/api/estado" && metodo === "GET") {
      return responder(res, 200, usuario ? banco.estado(usuario) : { perfil: null });
    }
    const corpo = ["POST", "PUT", "PATCH", "DELETE"].includes(metodo) ? await lerCorpo(req) : {};
    if (metodo === "POST" && ["/api/cadastro", "/api/entrar"].includes(caminho)) {
      if (usuario) throw new ErroHttp(409, "Você já está em uma conta.");
      const email = modelo.texto(corpo.email, 160, "e-mail", 3).toLowerCase();
      modelo.exigir(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email), "Informe um e-mail válido.");
      modelo.exigir(typeof corpo.senha === "string" && corpo.senha.length >= 8 && corpo.senha.length <= 128,
        "Use uma senha de 8 a 128 caracteres.");
      let id;
      if (caminho === "/api/cadastro") {
        const nome = modelo.texto(corpo.nome, 50, "nome", 2);
        const sal = randomBytes(16).toString("hex");
        const chave = await derivar(corpo.senha, sal, 64);
        const novo = db.prepare(`INSERT INTO usuarios (nome, email, sal, senha_hash) VALUES (?, ?, ?, ?)
          ON CONFLICT(email) DO NOTHING RETURNING id`).get(nome, email, sal, chave.toString("hex"));
        if (!novo) throw new ErroHttp(409, "Esse e-mail já tem uma conta.");
        id = novo.id;
      } else {
        const conta = db.prepare("SELECT id, sal, senha_hash FROM usuarios WHERE email = ?").get(email);
        const chave = await derivar(corpo.senha, conta?.sal || "soberbrain-login", 64);
        if (!conta || !timingSafeEqual(chave, Buffer.from(conta.senha_hash, "hex"))) {
          throw new ErroHttp(401, "Confira o e-mail e a senha.");
        }
        id = conta.id;
      }
      iniciarSessao(id, res, token);
      const perfil = db.prepare("SELECT id, nome, email FROM usuarios WHERE id = ?").get(id);
      return responder(res, caminho === "/api/cadastro" ? 201 : 200, banco.estado(perfil));
    }
    if (!usuario) throw new ErroHttp(401, "Sua sessão de conta terminou. Entre novamente pelo perfil.");
    if (caminho === "/api/sair" && metodo === "POST") {
      db.prepare("DELETE FROM sessoes WHERE token_hash = ?").run(hash(token));
      definirCookie(res, "", 0);
      return responder(res, 200, { ok: true });
    }
    if (caminho === "/api/perfil" && metodo === "PATCH") {
      usuario.nome = modelo.texto(corpo.nome, 50, "nome", 2);
      db.prepare("UPDATE usuarios SET nome = ? WHERE id = ?").run(usuario.nome, usuario.id);
    } else if (caminho === "/api/perfil" && metodo === "DELETE") {
      db.prepare("DELETE FROM usuarios WHERE id = ?").run(usuario.id);
      definirCookie(res, "", 0);
      return responder(res, 200, { ok: true });
    } else if (caminho.startsWith("/api/registros/")) {
      const data = modelo.validarData(caminho.slice("/api/registros/".length));
      if (metodo === "PUT") banco.salvarRegistro(usuario.id, modelo.validarRegistro({ ...corpo, data }));
      else if (metodo === "PATCH") banco.salvarHumor(usuario.id, data, modelo.validarHumor(corpo.humor));
      else if (metodo === "DELETE") {
        const resultado = db.prepare("DELETE FROM registros WHERE usuario_id = ? AND data = ?").run(usuario.id, data);
        if (!resultado.changes) throw new ErroHttp(404, "Registro não encontrado.");
      } else throw new ErroHttp(405, "Operação indisponível nesse registro.");
    } else if (caminho === "/api/metas" && metodo === "POST") {
      banco.criarMeta(usuario.id, modelo.validarMeta(corpo));
      return responder(res, 201, banco.estado(usuario));
    } else if (/^\/api\/metas\/[\w-]+(?:\/avancos)?$/.test(caminho)) {
      const [, , , id, acao] = caminho.split("/");
      const meta = db.prepare("SELECT progresso FROM metas WHERE id = ? AND usuario_id = ?").get(id, usuario.id);
      if (!meta) throw new ErroHttp(404, "Meta não encontrada.");
      if (acao === "avancos" && metodo === "POST") {
        db.prepare("UPDATE metas SET progresso = MIN(progresso + 1, alvo) WHERE id = ? AND usuario_id = ?").run(id, usuario.id);
      } else if (!acao && metodo === "PUT") {
        const nova = modelo.validarMeta(corpo, meta.progresso);
        db.prepare("UPDATE metas SET titulo = ?, alvo = ? WHERE id = ? AND usuario_id = ?").run(nova.titulo, nova.alvo, id, usuario.id);
      } else if (!acao && metodo === "DELETE") {
        db.prepare("DELETE FROM metas WHERE id = ? AND usuario_id = ?").run(id, usuario.id);
      } else throw new ErroHttp(405, "Operação indisponível nessa meta.");
    } else throw new ErroHttp(404, "Endereço de API não encontrado.");
    responder(res, 200, banco.estado(usuario));
  };
}

module.exports = { usarApi, responder, ErroHttp };
