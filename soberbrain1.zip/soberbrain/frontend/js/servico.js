/* Uma interface de dados para as telas. A conta usa fetch; o visitante usa a aba. */
(function (app) {
  "use strict";
  const m = app.modelo;
  const chave = "soberbrain.visitante.v1";
  const vazio = () => ({ perfil: { nome: "Eduardo" }, registros: [], metas: [] });
  let dados = vazio();
  let conta = false;
  let modo = "iniciando";
  let abaDisponivel = true;
  let cache = vazio();

  function trocarPerfil(proximo, autenticado) {
    dados = proximo;
    conta = autenticado;
    document.dispatchEvent(new Event("sb:troca-perfil"));
  }

  function lerVisitante() {
    try {
      const bruto = sessionStorage.getItem(chave);
      if (bruto) {
        const salvo = JSON.parse(bruto);
        if (typeof salvo?.perfil?.nome === "string" && Array.isArray(salvo.registros) && Array.isArray(salvo.metas)) cache = salvo;
      }
    } catch { abaDisponivel = false; }
    return cache;
  }

  function gravarVisitante(proximo) {
    if (abaDisponivel) {
      try { sessionStorage.setItem(chave, JSON.stringify(proximo)); }
      catch (erro) {
        if (erro.name === "QuotaExceededError") throw new Error("A aba está sem espaço. Exclua registros antigos para salvar.");
        abaDisponivel = false;
        document.dispatchEvent(new Event("sb:apenas-memoria"));
      }
    }
    dados = cache = proximo;
  }

  async function requisicao(caminho, metodo = "GET", corpo) {
    let resposta;
    try {
      resposta = await fetch("api/" + caminho, {
        method: metodo, credentials: "same-origin", cache: "no-store",
        headers: corpo ? { "Content-Type": "application/json", "X-Soberbrain": "1" } : {},
        body: corpo ? JSON.stringify(corpo) : undefined,
        signal: AbortSignal.timeout(12000)
      });
    } catch { throw new Error("A conexão com o servidor falhou. Tente novamente."); }
    if (!resposta.headers.get("Content-Type")?.includes("application/json")) {
      const erro = new Error("A API está indisponível.");
      erro.estatico = [200, 404].includes(resposta.status);
      throw erro;
    }
    const resultado = await resposta.json();
    if (!resposta.ok) {
      if (resposta.status === 401 && conta) {
        trocarPerfil(lerVisitante(), false);
        document.dispatchEvent(new Event("sb:sessao-expirada"));
      }
      const erro = new Error(resultado.erro || "A operação não foi concluída.");
      erro.estatico = caminho === "estado" && resposta.status === 404;
      throw erro;
    }
    return resultado;
  }

  async function iniciar() {
    dados = lerVisitante();
    if (location.protocol === "file:") { modo = "estatico"; return; }
    try {
      const estado = await requisicao("estado");
      modo = "online";
      if (estado.perfil) { conta = true; dados = estado; }
    } catch (erro) {
      if (erro.estatico) modo = "estatico";
      else { modo = "indisponivel"; throw erro; }
    }
  }

  async function alterar(caminho, metodo, corpo, aplicar) {
    if (modo === "indisponivel" || modo === "iniciando") throw new Error("Recarregue a página para reconectar antes de salvar.");
    if (conta) dados = await requisicao(caminho, metodo, corpo);
    else {
      const proximo = structuredClone(dados);
      aplicar(proximo);
      gravarVisitante(proximo);
    }
  }

  function registro(data) { return dados.registros.find(item => item.data === data); }
  function meta(id) { return dados.metas.find(item => item.id === id); }
  function substituirDia(estado, dia) {
    estado.registros = [dia, ...estado.registros.filter(item => item.data !== dia.data)]
      .sort((a, b) => b.data.localeCompare(a.data));
  }
  async function humor(data, id) {
    m.validarData(data); m.validarHumor(id);
    await alterar("registros/" + data, "PATCH", { humor: id }, estado =>
      substituirDia(estado, { ...(registro(data) || m.registroVazio(data)), humor: id }));
  }
  async function salvarRegistro(entrada) {
    const dia = m.validarRegistro(entrada);
    await alterar("registros/" + dia.data, "PUT", dia, estado => substituirDia(estado, dia));
  }
  async function excluirRegistro(data) {
    await alterar("registros/" + m.validarData(data), "DELETE", {}, estado => {
      estado.registros = estado.registros.filter(item => item.data !== data);
    });
  }
  async function salvarMeta(id, entrada) {
    const item = meta(id);
    const campos = m.validarMeta(entrada, item?.progresso || 0);
    await alterar(id ? "metas/" + id : "metas", id ? "PUT" : "POST", campos, estado => {
      if (id) Object.assign(estado.metas.find(atual => atual.id === id), campos);
      else estado.metas.push({ ...campos, id: crypto.getRandomValues(new Uint32Array(4)).join("-"), progresso: 0 });
    });
  }
  async function avancar(id) {
    await alterar("metas/" + id + "/avancos", "POST", {}, estado => {
      const item = estado.metas.find(atual => atual.id === id);
      item.progresso = Math.min(item.progresso + 1, item.alvo);
    });
  }
  async function excluirMeta(id) {
    await alterar("metas/" + id, "DELETE", {}, estado => {
      estado.metas = estado.metas.filter(item => item.id !== id);
    });
  }
  async function nome(valor) {
    const nome = m.texto(valor, 50, "nome", 2);
    await alterar("perfil", "PATCH", { nome }, estado => { estado.perfil.nome = nome; });
  }
  async function autenticar(acao, credenciais) {
    if (modo !== "online") throw new Error("Abra a versão com servidor para usar uma conta.");
    trocarPerfil(await requisicao(acao, "POST", credenciais), true);
  }
  async function sair() {
    await requisicao("sair", "POST", {});
    trocarPerfil(lerVisitante(), false);
  }
  async function apagarPerfil() {
    if (conta) {
      await requisicao("perfil", "DELETE", {});
      trocarPerfil(lerVisitante(), false);
    } else {
      if (modo === "indisponivel") throw new Error("Reconecte antes de apagar os dados.");
      if (abaDisponivel) sessionStorage.removeItem(chave);
      cache = vazio();
      trocarPerfil(cache, false);
    }
  }
  app.servico = { get dados() { return dados; }, get conta() { return conta; }, get modo() { return modo; },
    get abaDisponivel() { return abaDisponivel; }, iniciar, registro, meta, humor, salvarRegistro, excluirRegistro,
    salvarMeta, avancar, excluirMeta, nome, autenticar, sair, apagarPerfil };
}(window.Soberbrain));
