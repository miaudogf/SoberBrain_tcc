(function (app) {
  "use strict";
  const m = app.modelo;
  const porId = id => document.getElementById(id);
  function elemento(tag, conteudo, classe) {
    const item = document.createElement(tag);
    if (conteudo !== undefined) item.textContent = conteudo;
    if (classe) item.className = classe;
    return item;
  }
  function nomeHumor(id) { return m.humores.find(item => item.id === id)?.nome || ""; }
  function imagemHumor(id) {
    const img = elemento("img");
    img.alt = "";
    img.src = "assets/img/humores/" + id + ".png";
    img.width = 124;
    img.height = 123;
    return img;
  }
  function dataFormatada(data, opcoes = { day: "2-digit", month: "2-digit", year: "numeric" }) {
    return m.dataLocal(data).toLocaleDateString("pt-BR", opcoes);
  }
  function maiuscula(texto) { return texto[0].toLocaleUpperCase("pt-BR") + texto.slice(1); }
  let temporizador;
  function avisar(mensagem, erro = false) {
    clearTimeout(temporizador);
    const caixa = porId("mensagem");
    caixa.classList.toggle("erro", erro);
    caixa.textContent = mensagem;
    temporizador = setTimeout(() => { caixa.textContent = ""; }, erro ? 7500 : 3700);
  }
  let ocupado = false;
  async function executar(tarefa, sucesso) {
    if (ocupado) return;
    ocupado = true;
    const tela = porId("conteudo");
    tela.setAttribute("aria-busy", "true");
    try {
      await tarefa();
      document.dispatchEvent(new Event("sb:alteracao"));
      if (sucesso) avisar(sucesso);
    } catch (erro) { avisar(erro.message, true); }
    finally { ocupado = false; tela.removeAttribute("aria-busy"); }
  }
  function dialogo(titulo, paragrafos, confirmar = "") {
    const caixa = porId("dialogo");
    porId("dialogo-titulo").textContent = titulo;
    porId("dialogo-corpo").replaceChildren(...paragrafos.map(p => elemento("p", p)));
    porId("dialogo-fechar").textContent = confirmar ? "Cancelar" : "Fechar";
    const acao = porId("dialogo-confirmar");
    acao.hidden = !confirmar; acao.textContent = confirmar;
    caixa.returnValue = "";
    caixa.showModal();
    return new Promise(resolve => {
      caixa.addEventListener("close", () => resolve(caixa.returnValue === "confirmar"), { once: true });
    });
  }
  app.ui = { porId, elemento, nomeHumor, imagemHumor, dataFormatada, maiuscula, avisar, executar, dialogo };
}(window.Soberbrain));
