(function (app) {
  "use strict";
  const m = app.modelo, s = app.servico;
  const { porId, elemento, imagemHumor, nomeHumor, dataFormatada, maiuscula } = app.ui;
  let selecionado = m.hoje();
  const anoMes = data => data.slice(0, 7);

  function mostrarDetalhe() {
    const registro = s.registro(selecionado);
    porId("cal-dia-titulo").textContent = dataFormatada(selecionado, { day: "numeric", month: "long" });
    const bloco = porId("cal-detalhe");
    bloco.replaceChildren();
    const link = porId("cal-editar");
    link.href = "#diario/" + selecionado;
    link.textContent = registro ? "Editar no diário" : "Registrar este dia";
    if (!registro) { bloco.append(elemento("p", "Este dia ainda está em branco.", "secundario")); return; }
    const leitura = elemento("p", undefined, "leitura-dia");
    leitura.append(imagemHumor(registro.humor), nomeHumor(registro.humor));
    bloco.append(leitura);
    if (registro.consumo) bloco.append(elemento("p", m.consumos[registro.consumo]));
    for (const campo of ["substancia", "quantidade", "contexto"]) {
      if (registro[campo]) bloco.append(elemento("p", registro[campo], "secundario"));
    }
    if (registro.atividades.length) bloco.append(elemento("p", registro.atividades.map(id => m.atividades[id]).join(" · "), "secundario"));
    if (registro.nota) bloco.append(elemento("p", registro.nota, "nota-pessoal"));
  }

  function estatisticas(mes) {
    const registros = s.dados.registros.filter(item => anoMes(item.data) === mes);
    const n = registros.length;
    porId("stats-total").textContent = n === 1 ? "1 dia com registro." : n + " dias com registro.";
    const frequencias = new Map();
    for (const dia of registros) for (const id of dia.atividades) frequencias.set(id, (frequencias.get(id) || 0) + 1);
    const maisComum = [...frequencias].sort((a, b) => b[1] - a[1]);
    const atividade = porId("stats-atividade");
    atividade.hidden = !maisComum.length;
    if (maisComum.length) {
      const quantidade = maisComum[0][1];
      const nomes = maisComum.filter(([, total]) => total === quantidade).map(([id]) => m.atividades[id]).join(", ");
      atividade.textContent = "Mais presente no mês · " + nomes + " (" + quantidade + (quantidade === 1 ? " dia)." : " dias).");
    }
    const lista = porId("stats-barras");
    lista.replaceChildren();
    for (const humor of m.humores) {
      const total = registros.filter(item => item.humor === humor.id).length;
      const linha = elemento("li");
      const barra = elemento("progress");
      barra.max = Math.max(n, 1); barra.value = total; barra.style.setProperty("--cor-barra", humor.cor);
      barra.setAttribute("aria-label", humor.nome + ", " + total + " de " + n + " dias registrados");
      linha.append(elemento("span", humor.nome), barra, elemento("span", String(total)));
      lista.append(linha);
    }
  }

  function mostrar(data = selecionado) {
    selecionado = data;
    const mes = anoMes(data), hoje = m.hoje();
    const primeiro = m.dataLocal(mes + "-01");
    const ultimo = new Date(primeiro.getFullYear(), primeiro.getMonth() + 1, 0, 12);
    porId("cal-mes").textContent = maiuscula(dataFormatada(data, { month: "long", year: "numeric" }));
    porId("mes-seguinte").disabled = mes >= anoMes(hoje);
    porId("mes-anterior").disabled = mes <= "1900-01";
    const grade = porId("cal-dias");
    grade.replaceChildren();
    for (let i = 0; i < (primeiro.getDay() + 6) % 7; i++) grade.append(elemento("span"));
    const porData = new Map(s.dados.registros.map(registro => [registro.data, registro]));
    for (let dia = 1; dia <= ultimo.getDate(); dia++) {
      const chave = mes + "-" + String(dia).padStart(2, "0");
      const registro = porData.get(chave);
      const botao = elemento("button", String(dia), "cal-dia");
      botao.type = "button"; botao.dataset.data = chave; botao.disabled = chave > hoje;
      botao.setAttribute("aria-pressed", String(chave === selecionado));
      botao.setAttribute("aria-label", dataFormatada(chave) + (registro ? ", " + nomeHumor(registro.humor) : ", sem registro"));
      if (chave === hoje) botao.setAttribute("aria-current", "date");
      if (registro) botao.append(imagemHumor(registro.humor));
      grade.append(botao);
    }
    mostrarDetalhe();
    estatisticas(mes);
  }

  function mudarMes(delta) {
    const data = m.dataLocal(anoMes(selecionado) + "-01");
    data.setMonth(data.getMonth() + delta);
    const chave = m.chaveData(data);
    mostrar(anoMes(chave) === anoMes(m.hoje()) ? m.hoje() : chave);
  }
  porId("cal-dias").addEventListener("click", evento => {
    const alvo = evento.target.closest("button[data-data]");
    if (!alvo) return;
    selecionado = alvo.dataset.data;
    for (const botao of porId("cal-dias").querySelectorAll("button")) botao.setAttribute("aria-pressed", String(botao === alvo));
    mostrarDetalhe();
  });
  porId("mes-anterior").addEventListener("click", () => mudarMes(-1));
  porId("mes-seguinte").addEventListener("click", () => mudarMes(1));
  porId("mes-hoje").addEventListener("click", () => mostrar(m.hoje()));
  app.calendario = { mostrar };
}(window.Soberbrain));
