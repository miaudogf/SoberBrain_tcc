(function (app) {
  "use strict";
  const m = app.modelo, s = app.servico;
  const { porId, elemento, imagemHumor, executar, dialogo, dataFormatada } = app.ui;
  const form = porId("form-diario");
  const campos = form.elements;

  for (const humor of m.humores) {
    const rotulo = elemento("label", undefined, "opcao-humor");
    const radio = elemento("input");
    radio.type = "radio"; radio.name = "humor"; radio.value = humor.id; radio.required = true;
    radio.setAttribute("aria-label", humor.nome);
    const figura = elemento("span", undefined, "figura-humor");
    figura.setAttribute("aria-hidden", "true");
    figura.append(imagemHumor(humor.id));
    rotulo.append(radio, figura, elemento("span", humor.nome));
    porId("humores-diario").append(rotulo);
  }
  for (const [id, nome] of Object.entries(m.atividades)) {
    const rotulo = elemento("label", undefined, "atividade");
    const caixa = elemento("input");
    caixa.type = "checkbox"; caixa.name = "atividades"; caixa.value = id;
    rotulo.append(caixa, nome); porId("atividades-diario").append(rotulo);
  }
  function detalhes() {
    const consumo = campos.consumo.value;
    porId("detalhes-consumo").hidden = !["vontade", "sim"].includes(consumo);
    porId("campo-quantidade").hidden = consumo !== "sim";
  }
  function mostrar(data) {
    campos.data.max = m.hoje();
    const registro = s.registro(data);
    const dia = registro || m.registroVazio(data);
    for (const nome of ["data", "consumo", "substancia", "quantidade", "contexto", "nota"]) campos[nome].value = dia[nome];
    for (const radio of campos.humor) radio.checked = radio.value === dia.humor;
    for (const caixa of campos.atividades) caixa.checked = dia.atividades.includes(caixa.value);
    porId("diario-situacao").textContent = registro ? "Editando registro" : "Novo registro";
    porId("excluir-registro").hidden = !registro;
    detalhes();
  }
  campos.consumo.addEventListener("change", detalhes);
  campos.data.addEventListener("change", () => {
    if (campos.data.value && campos.data.reportValidity()) location.hash = "diario/" + campos.data.value;
  });
  form.addEventListener("submit", evento => {
    evento.preventDefault();
    const dados = new FormData(form);
    const registro = Object.fromEntries(dados);
    registro.atividades = dados.getAll("atividades");
    executar(() => s.salvarRegistro(registro), "Registro salvo no diário.");
  });
  porId("excluir-registro").addEventListener("click", async () => {
    const data = campos.data.value;
    if (await dialogo("Excluir este registro?", ["O registro de " + dataFormatada(data) + " será removido do diário e do calendário."], "Excluir registro")) {
      executar(() => s.excluirRegistro(data), "Registro excluído.");
    }
  });
  app.diario = { mostrar };
}(window.Soberbrain));
