(async function (app) {
  "use strict";
  const m = app.modelo, s = app.servico;
  const { porId, elemento, nomeHumor, imagemHumor, dataFormatada, maiuscula, avisar, executar, dialogo } = app.ui;
  const titulos = { home: "Home", diario: "Diário", calendario: "Calendário", metas: "Metas", perfil: "Perfil" };
  const ajuda = {
    privacidade: ["Política de privacidade", "No modo visitante, o diário fica na sessão desta aba. Em uma conta, os registros e as metas ficam no banco de dados do servidor do projeto.", "Você pode editar ou excluir um registro pelo diário. A exclusão de todos os dados fica em Meu perfil."],
    termos: ["Termos de serviço", "O SoberBrain é um projeto acadêmico de autoconhecimento. Você escolhe o que registrar e pode pular os campos sobre consumo.", "Os resumos descrevem os registros que você fez. O aplicativo não oferece diagnóstico nem substitui acompanhamento profissional."],
    faq: ["Perguntas frequentes", "Como registro meu humor? Toque em uma das cinco carinhas da Home. Para acrescentar detalhes, abra Conte do seu dia.", "Posso preencher outro dia? Escolha uma data passada no diário ou no calendário.", "Como funcionam as metas? Cada passo fica acumulado até você completar o objetivo."]
  };
  for (const humor of m.humores) {
    const botao = elemento("button", undefined, "carinha");
    botao.type = "button"; botao.dataset.humor = humor.id; botao.title = humor.nome;
    botao.setAttribute("aria-label", humor.nome); botao.setAttribute("aria-pressed", "false");
    botao.append(imagemHumor(humor.id));
    porId("humores-home").append(botao);
  }
  porId("humores-home").addEventListener("click", evento => {
    const botao = evento.target.closest("button[data-humor]");
    if (botao) executar(() => s.humor(m.hoje(), botao.dataset.humor), "Humor de hoje registrado · " + botao.title);
  });
  function semana(hoje) {
    const inicio = m.dataLocal(hoje);
    inicio.setDate(inicio.getDate() - (inicio.getDay() + 6) % 7);
    const lista = porId("semana-dias");
    lista.replaceChildren();
    let quantidade = 0;
    let ultimo;
    for (let i = 0; i < 7; i++) {
      const dia = new Date(inicio); dia.setDate(inicio.getDate() + i);
      ultimo = m.chaveData(dia);
      const registro = s.registro(ultimo);
      if (registro) quantidade++;
      const linha = elemento("li");
      const link = elemento(ultimo > hoje ? "span" : "a", undefined, "dia-semana");
      const rotulo = dataFormatada(ultimo) + (registro ? ", " + nomeHumor(registro.humor) : ", sem registro");
      if (ultimo <= hoje) link.href = "#calendario/" + ultimo;
      link.setAttribute("aria-label", rotulo);
      link.title = rotulo;
      if (ultimo === hoje) link.setAttribute("aria-current", "date");
      const bolha = elemento("span", undefined, "bolha-dia");
      bolha.append(registro ? imagemHumor(registro.humor) : String(dia.getDate()));
      link.append(elemento("span", ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"][i]), bolha);
      linha.append(link); lista.append(linha);
    }
    const curta = { day: "2-digit", month: "2-digit" };
    porId("semana-periodo").textContent = dataFormatada(m.chaveData(inicio), curta) + " – " + dataFormatada(ultimo, curta);
    porId("semana-total").textContent = quantidade === 1 ? "1 dia registrado" : quantidade + " dias registrados";
  }
  function mostrarHome() {
    const hoje = m.hoje(), atual = s.registro(hoje);
    porId("nome-home").textContent = s.dados.perfil.nome;
    porId("data-home").dateTime = hoje;
    porId("data-home").textContent = maiuscula(dataFormatada(hoje, { weekday: "long" })) + " – " + dataFormatada(hoje);
    for (const botao of porId("humores-home").children) botao.setAttribute("aria-pressed", String(atual?.humor === botao.dataset.humor));
    porId("conte-dia").href = "#diario/" + hoje;
    semana(hoje);
    const ultimo = s.dados.registros[0];
    porId("ultimo-resumo").textContent = ultimo ? dataFormatada(ultimo.data) + " · " + nomeHumor(ultimo.humor) : "Seu primeiro registro aparece aqui.";
    porId("ultimo-link").href = "#diario/" + (ultimo?.data || hoje);
    porId("ultimo-link").textContent = ultimo ? "Rever registro" : "Abrir diário";
    const meta = s.dados.metas.find(item => item.progresso < item.alvo) || s.dados.metas[0];
    porId("meta-resumo").textContent = meta ? meta.titulo + " · " + meta.progresso + "/" + meta.alvo : "O que você gostaria de fazer mais vezes?";
    porId("meta-link").textContent = meta ? "Acompanhar metas" : "Criar uma meta";
  }

  function rota() {
    const [identificador, parametro] = location.hash.slice(1).split("/");
    const tela = Object.hasOwn(titulos, identificador) ? identificador : "home";
    let data;
    if (parametro) { try { data = m.validarData(parametro); } catch { data = undefined; } }
    return { tela, data };
  }
  function renderizar(navegacao = false) {
    const { tela, data } = rota();
    for (const secao of document.querySelectorAll(".tela")) secao.hidden = secao.id !== "tela-" + tela;
    for (const link of document.querySelectorAll(".navegacao a, .perfil-link")) {
      if (link.hash === "#" + tela) link.setAttribute("aria-current", "page");
      else link.removeAttribute("aria-current");
    }
    document.title = titulos[tela] + " · SoberBrain";
    if (tela === "home") mostrarHome();
    else if (tela === "diario") app.diario.mostrar(data || m.hoje());
    else if (tela === "calendario") app.calendario.mostrar(data);
    else if (tela === "metas") app.metas.mostrar();
    else app.perfil.mostrar();
    if (navegacao) {
      porId("conteudo").focus({ preventScroll: true });
      window.scrollTo(0, 0);
    }
  }
  function avisoFixo(mensagem) {
    porId("aviso-rede").textContent = mensagem;
    porId("aviso-rede").hidden = false;
  }
  for (const botao of document.querySelectorAll("[data-ajuda]")) botao.addEventListener("click", () => {
    const [titulo, ...paragrafos] = ajuda[botao.dataset.ajuda];
    dialogo(titulo, paragrafos);
  });
  document.querySelector(".pular").addEventListener("click", evento => {
    evento.preventDefault(); porId("conteudo").focus();
  });
  document.addEventListener("sb:alteracao", () => renderizar());
  document.addEventListener("sb:troca-perfil", () => {
    // Atualiza também as telas ocultas ao sair ou trocar de diário.
    mostrarHome(); app.diario.mostrar(m.hoje()); app.calendario.mostrar(m.hoje()); app.metas.mostrar(); app.perfil.mostrar();
  });
  document.addEventListener("sb:sessao-expirada", () => {
    location.hash = "perfil"; renderizar(); avisar("Entre novamente para abrir os registros da sua conta.", true);
  });
  document.addEventListener("sb:apenas-memoria", () => avisoFixo("O navegador bloqueou o armazenamento. Os registros de visitante duram até recarregar a página."));
  window.addEventListener("hashchange", () => renderizar(true));
  porId("ano-rodape").textContent = m.hoje().slice(0, 4);
  porId("conteudo").inert = true;
  renderizar();
  try { await s.iniciar(); }
  catch (erro) { avisoFixo(erro.message + " Recarregue a página para reconectar."); }
  if (!s.abaDisponivel && !s.conta) document.dispatchEvent(new Event("sb:apenas-memoria"));
  porId("conteudo").inert = false;
  renderizar();
}(window.Soberbrain));
