/* O navegador e a API usam as mesmas regras para datas, humores e formulários. */
(function () {
  "use strict";

  const humores = [
    { id: "muito-mal", nome: "Muito mal", cor: "#ba7469" },
    { id: "mal", nome: "Mal", cor: "#ce9478" },
    { id: "neutro", nome: "Neutro", cor: "#aa8eb0" },
    { id: "bem", nome: "Bem", cor: "#98a696" },
    { id: "muito-bem", nome: "Muito bem", cor: "#78967d" }
  ];
  const atividades = {
    exercicio: "Exercício", estudo: "Estudo", trabalho: "Trabalho",
    descanso: "Descanso", companhia: "Com outras pessoas", ansiedade: "Ansiedade", conflito: "Conflito"
  };
  const consumos = { "": "Prefiro pular", nao: "Sem consumo", vontade: "Senti vontade", sim: "Houve consumo" };

  class ErroEntrada extends Error {}

  function exigir(condicao, mensagem) {
    if (!condicao) throw new ErroEntrada(mensagem);
  }

  function texto(valor, limite, rotulo, minimo = 0) {
    exigir(typeof valor === "string", "Revise o campo " + rotulo + ".");
    const limpo = valor.trim();
    exigir(limpo.length >= minimo && limpo.length <= limite, "Revise o tamanho do campo " + rotulo + ".");
    return limpo;
  }

  function chaveData(data) {
    return [data.getFullYear(), String(data.getMonth() + 1).padStart(2, "0"),
      String(data.getDate()).padStart(2, "0")].join("-");
  }

  function hoje() {
    // Um só fuso mantém o calendário e o servidor de acordo na virada do dia.
    const partes = new Intl.DateTimeFormat("pt-BR", {
      timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit"
    }).formatToParts(new Date());
    const obter = tipo => partes.find(parte => parte.type === tipo).value;
    return [obter("year"), obter("month"), obter("day")].join("-");
  }

  function dataLocal(chave) { return new Date(chave + "T12:00:00"); }

  function validarData(chave) {
    exigir(typeof chave === "string" && /^\d{4}-\d{2}-\d{2}$/.test(chave)
      && chave >= "1900-01-01" && chave <= hoje() && chaveData(dataLocal(chave)) === chave,
    "Escolha uma data válida até hoje.");
    return chave;
  }

  function validarHumor(id) {
    exigir(humores.some(item => item.id === id), "Escolha uma das cinco carinhas.");
    return id;
  }

  function registroVazio(data) {
    return { data, humor: "", consumo: "", substancia: "", quantidade: "", contexto: "", atividades: [], nota: "" };
  }

  function validarRegistro(entrada) {
    const data = validarData(entrada.data);
    const humor = validarHumor(entrada.humor);
    exigir(Object.hasOwn(consumos, entrada.consumo), "Revise a opção de consumo.");
    exigir(Array.isArray(entrada.atividades) && entrada.atividades.every(id => typeof id === "string" && Object.hasOwn(atividades, id)),
      "Revise as atividades selecionadas.");
    const detalhes = ["sim", "vontade"].includes(entrada.consumo);
    return {
      data, humor, consumo: entrada.consumo, atividades: [...new Set(entrada.atividades)],
      substancia: detalhes ? texto(entrada.substancia, 80, "substância") : "",
      quantidade: entrada.consumo === "sim" ? texto(entrada.quantidade, 50, "quantidade") : "",
      contexto: detalhes ? texto(entrada.contexto, 180, "contexto") : "",
      nota: texto(entrada.nota, 1200, "reflexão")
    };
  }

  function validarMeta(entrada, progresso = 0) {
    const titulo = texto(entrada.titulo, 80, "título da meta", 2);
    const alvo = entrada.alvo;
    exigir(Number.isInteger(alvo) && alvo >= Math.max(1, progresso) && alvo <= 365,
      "A meta precisa de 1 a 365 passos e deve incluir os avanços já registrados.");
    return { titulo, alvo };
  }

  const modelo = { humores, atividades, consumos, ErroEntrada, exigir, texto, hoje, chaveData,
    dataLocal, validarData, validarHumor, registroVazio, validarRegistro, validarMeta };
  if (typeof module === "object" && module.exports) module.exports = modelo;
  else window.Soberbrain = { modelo };
}());
