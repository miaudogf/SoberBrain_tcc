(function (app) {
  "use strict";
  const s = app.servico;
  const { porId, elemento, executar, dialogo } = app.ui;
  const formMeta = porId("form-meta"), formAuth = porId("form-auth");
  let idEdicao = null;
  let cadastro = false;

  function editarMeta(id) {
    const meta = id ? s.meta(id) : null;
    idEdicao = meta?.id || null;
    formMeta.reset();
    formMeta.elements.titulo.value = meta?.titulo || "";
    formMeta.elements.alvo.value = meta?.alvo || "";
    formMeta.elements.alvo.min = Math.max(1, meta?.progresso || 0);
    porId("meta-form-titulo").textContent = meta ? "Editar meta" : "Criar uma meta";
    porId("meta-salvar").textContent = meta ? "Salvar alterações" : "Criar meta";
    porId("meta-cancelar").hidden = !meta;
    if (meta) formMeta.elements.titulo.focus();
  }
  function botaoMeta(acao, rotulo, classe) {
    const botao = elemento("button", rotulo, classe);
    botao.type = "button"; botao.dataset.acao = acao;
    return botao;
  }
  function mostrarMetas() {
    if (idEdicao && !s.meta(idEdicao)) editarMeta(null);
    const lista = porId("lista-metas");
    lista.replaceChildren();
    if (!s.dados.metas.length) {
      const vazio = elemento("article", undefined, "painel item-meta");
      vazio.append(elemento("h2", "Suas metas"), elemento("p", "Quando você criar uma meta, os passos registrados aparecem aqui.", "secundario"));
      lista.append(vazio);
    }
    for (const meta of s.dados.metas) {
      const completa = meta.progresso >= meta.alvo;
      const card = elemento("article", undefined, "painel item-meta"); card.dataset.id = meta.id;
      const texto = meta.progresso + " de " + meta.alvo + (meta.alvo === 1 ? " passo" : " passos");
      const barra = elemento("progress"); barra.max = meta.alvo; barra.value = meta.progresso;
      barra.setAttribute("aria-label", meta.titulo + ", " + texto);
      const acoes = elemento("div", undefined, "acoes");
      if (!completa) acoes.append(botaoMeta("avancar", "Marcar um passo", "primario"));
      acoes.append(botaoMeta("editar", "Editar", "texto"), botaoMeta("excluir", "Excluir", "texto excluir"));
      card.append(elemento("h2", meta.titulo), elemento("span", texto + (completa ? " · Concluída" : "")), barra, acoes);
      lista.append(card);
    }
  }
  formMeta.addEventListener("submit", evento => {
    evento.preventDefault();
    const id = idEdicao;
    const campos = { titulo: formMeta.elements.titulo.value, alvo: formMeta.elements.alvo.valueAsNumber };
    executar(async () => { await s.salvarMeta(id, campos); editarMeta(null); }, id ? "Meta atualizada." : "Meta criada.");
  });
  porId("meta-cancelar").addEventListener("click", () => editarMeta(null));
  porId("lista-metas").addEventListener("click", async evento => {
    const alvo = evento.target.closest("button[data-acao]");
    if (!alvo) return;
    const id = alvo.closest("article").dataset.id;
    if (alvo.dataset.acao === "editar") return editarMeta(id);
    if (alvo.dataset.acao === "avancar") return executar(() => s.avancar(id), "Passo registrado.");
    if (await dialogo("Excluir esta meta?", ["“" + s.meta(id).titulo + "” e seus passos serão removidos."], "Excluir meta")) {
      executar(() => s.excluirMeta(id), "Meta excluída.");
    }
  });

  function modoAuth(criar) {
    cadastro = criar;
    porId("modo-entrar").setAttribute("aria-pressed", String(!criar));
    porId("modo-cadastro").setAttribute("aria-pressed", String(criar));
    porId("nome-cadastro").hidden = !criar;
    formAuth.elements.nome.required = criar;
    formAuth.elements.nome.disabled = !criar;
    formAuth.elements.senha.autocomplete = criar ? "new-password" : "current-password";
    porId("auth-enviar").textContent = criar ? "Criar minha conta" : "Entrar na conta";
    if (criar && !formAuth.elements.nome.value) formAuth.elements.nome.value = s.dados.perfil.nome;
  }
  function mostrarPerfil() {
    const perfil = s.dados.perfil;
    porId("perfil-modo").textContent = s.conta ? "Conta de " + perfil.email : "Você está usando o modo visitante.";
    porId("form-nome").elements.nome.value = perfil.nome;
    porId("perfil-dados-texto").textContent = s.conta
      ? "O diário e as metas ficam vinculados a esta conta."
      : s.abaDisponivel ? "O diário de visitante fica nesta aba. Fechar a aba encerra essa sessão."
        : "O navegador bloqueou o armazenamento da aba. Seus dados duram até recarregar ou fechar a página.";
    porId("sair").hidden = !s.conta;
    porId("apagar-perfil").textContent = s.conta ? "Excluir minha conta" : "Apagar dados de visitante";
    porId("conta-painel").hidden = s.conta;
    porId("area-auth").hidden = s.modo !== "online";
    porId("conta-explicacao").textContent = s.modo === "online"
      ? "Use uma conta para voltar ao seu diário em outra sessão. Os registros de visitante continuam separados nesta aba."
      : s.modo === "estatico" ? "Para usar cadastro e login, execute npm start na pasta do projeto e abra http://localhost:3000."
        : "O servidor está indisponível. Recarregue a página para tentar de novo.";
    modoAuth(cadastro);
  }
  porId("modo-entrar").addEventListener("click", () => modoAuth(false));
  porId("modo-cadastro").addEventListener("click", () => modoAuth(true));
  porId("form-nome").addEventListener("submit", evento => {
    evento.preventDefault();
    executar(() => s.nome(evento.target.elements.nome.value), "Nome atualizado.");
  });
  formAuth.addEventListener("submit", evento => {
    evento.preventDefault();
    const campos = Object.fromEntries(new FormData(formAuth));
    executar(async () => {
      await s.autenticar(cadastro ? "cadastro" : "entrar", campos);
      formAuth.reset(); modoAuth(false); editarMeta(null);
    }, cadastro ? "Conta criada." : "Você entrou na conta.");
  });
  porId("sair").addEventListener("click", () => executar(async () => {
    await s.sair(); editarMeta(null); modoAuth(false);
  }, "Você voltou ao perfil de visitante."));
  porId("apagar-perfil").addEventListener("click", async () => {
    const titulo = s.conta ? "Excluir sua conta e seus registros?" : "Apagar o diário de visitante?";
    const mensagem = s.conta ? "O perfil, as metas e todos os registros desta conta serão excluídos."
      : "O nome, as metas e os registros de visitante desta aba serão apagados.";
    if (await dialogo(titulo, [mensagem], "Excluir")) executar(async () => {
      await s.apagarPerfil(); editarMeta(null); formAuth.reset(); modoAuth(false);
    }, "Dados excluídos.");
  });
  app.metas = { mostrar: mostrarMetas };
  app.perfil = { mostrar: mostrarPerfil };
}(window.Soberbrain));
