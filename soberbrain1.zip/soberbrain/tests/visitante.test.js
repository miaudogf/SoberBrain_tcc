const { test } = require("node:test");
const assert = require("node:assert/strict");
const { readFileSync } = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const { webcrypto } = require("node:crypto");
const modelo = require("../frontend/js/modelo");

const codigo = readFileSync(path.join(__dirname, "../frontend/js/servico.js"), "utf8");
function abrirAba(memoria) {
  const app = { modelo };
  vm.runInNewContext(codigo, {
    window: { Soberbrain: app }, location: { protocol: "file:" }, structuredClone,
    crypto: webcrypto, document: new EventTarget(), Event,
    fetch: () => assert.fail("O modo arquivo tentou uma requisição de rede."),
    sessionStorage: {
      getItem: chave => memoria.get(chave) ?? null,
      setItem: (chave, valor) => memoria.set(chave, valor),
      removeItem: chave => memoria.delete(chave)
    }
  });
  return app.servico;
}
test("visitante consegue usar o diário e as metas ao abrir o HTML como arquivo", async () => {
  const memoria = new Map(), data = modelo.hoje();
  let aba = abrirAba(memoria);
  await aba.iniciar();
  assert.equal(aba.modo, "estatico");
  await aba.salvarRegistro({ ...modelo.registroVazio(data), humor: "mal", atividades: ["estudo"], nota: "Fiz uma pausa." });
  await aba.humor(data, "bem");
  await aba.salvarMeta(null, { titulo: "Fazer uma pausa", alvo: 3 });
  await aba.avancar(aba.dados.metas[0].id);
  aba = abrirAba(memoria);
  await aba.iniciar();
  assert.equal(aba.dados.registros.length, 1);
  assert.equal(aba.registro(data).nota, "Fiz uma pausa.");
  assert.equal(aba.registro(data).humor, "bem");
  assert.equal(aba.dados.metas[0].progresso, 1);
  await aba.apagarPerfil();
  assert.equal(aba.dados.registros.length + aba.dados.metas.length, 0);
  assert.equal(memoria.size, 0);
});
