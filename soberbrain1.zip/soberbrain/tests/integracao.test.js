const { test } = require("node:test");
const assert = require("node:assert/strict");
const { mkdtemp, rm } = require("node:fs/promises");
const path = require("node:path");
const { tmpdir } = require("node:os");
const { randomBytes } = require("node:crypto");
const { criarServidor } = require("../backend/servidor");
const { hoje, registroVazio } = require("../frontend/js/modelo");

async function iniciar(arquivo) {
  const servidor = criarServidor(arquivo);
  await new Promise(resolve => servidor.listen(0, "127.0.0.1", resolve));
  return { base: "http://127.0.0.1:" + servidor.address().port,
    fechar: () => new Promise(resolve => servidor.close(resolve)) };
}
function cliente(base) {
  let cookie = "";
  return async function chamar(rota, metodo = "GET", dados) {
    const resposta = await fetch(base + "/api/" + rota, {
      method: metodo, headers: { Cookie: cookie, "Content-Type": "application/json", "X-Soberbrain": "1" },
      body: dados === undefined ? undefined : JSON.stringify(dados)
    });
    const sessao = resposta.headers.get("set-cookie");
    if (sessao) cookie = sessao.split(";")[0];
    return { status: resposta.status, dados: await resposta.json() };
  };
}
const conta = { nome: "Pessoa de teste", email: "teste@example.test", senha: randomBytes(18).toString("hex") };

test("diário, humor rápido, calendário e exclusão usam o mesmo registro persistido", async t => {
  const diretorio = await mkdtemp(path.join(tmpdir(), "sb-teste-"));
  const arquivo = path.join(diretorio, "teste.sqlite");
  let app = await iniciar(arquivo);
  t.after(async () => { await app.fechar(); await rm(diretorio, { recursive: true, force: true }); });
  const chamar = cliente(app.base);
  assert.equal((await chamar("estado")).dados.perfil, null);
  assert.equal((await chamar("cadastro", "POST", conta)).status, 201);
  const url = "registros/" + hoje();
  const exemplo = { ...registroVazio(hoje()), humor: "bem", nota: "Caminhei no parque.",
    atividades: ["exercicio", "companhia"], consumo: "vontade", contexto: "Fim de tarde" };
  let resposta = await chamar(url, "PUT", exemplo);
  assert.equal(resposta.status, 200);
  assert.deepEqual(resposta.dados.registros[0].atividades.sort(), exemplo.atividades.sort());
  resposta = await chamar(url, "PATCH", { humor: "neutro" });
  assert.equal(resposta.dados.registros.length, 1);
  assert.equal(resposta.dados.registros[0].nota, exemplo.nota);
  assert.equal(resposta.dados.registros[0].contexto, exemplo.contexto);
  assert.equal(resposta.dados.registros[0].humor, "neutro");
  assert.equal((await chamar(url, "PUT", { ...exemplo, humor: "invalido" })).status, 422);
  assert.equal((await chamar("registros/2025-02-30", "PATCH", { humor: "mal" })).status, 422);
  await app.fechar();
  app = await iniciar(arquivo);
  const voltar = cliente(app.base);
  assert.equal((await voltar("entrar", "POST", conta)).dados.registros[0].nota, exemplo.nota);
  resposta = await voltar(url, "PUT", { ...exemplo, consumo: "", atividades: [], nota: "Voltei ao parque." });
  assert.equal(resposta.dados.registros[0].consumo, "");
  assert.equal(resposta.dados.registros[0].contexto, "");
  assert.deepEqual(resposta.dados.registros[0].atividades, []);
  assert.deepEqual((await voltar(url, "DELETE", {})).dados.registros, []);
});

test("metas acumulam passos e respeitam os limites e a separação entre perfis", async t => {
  const app = await iniciar(":memory:");
  t.after(app.fechar);
  const a = cliente(app.base), b = cliente(app.base);
  await a("cadastro", "POST", conta);
  await b("cadastro", "POST", { ...conta, email: "segunda@example.test" });
  const criada = await a("metas", "POST", { titulo: "Caminhar", alvo: 2 });
  assert.equal(criada.status, 201);
  const url = "metas/" + criada.dados.metas[0].id;
  assert.deepEqual((await b("estado")).dados.metas, []);
  assert.equal((await b(url + "/avancos", "POST", {})).status, 404);
  await Promise.all([a(url + "/avancos", "POST", {}), a(url + "/avancos", "POST", {})]);
  assert.equal((await a(url + "/avancos", "POST", {})).dados.metas[0].progresso, 2);
  assert.equal((await a(url, "PUT", { titulo: "Caminhar mais", alvo: 1 })).status, 422);
  assert.equal((await a(url, "PUT", { titulo: "Caminhar mais", alvo: 3 })).dados.metas[0].alvo, 3);
  assert.deepEqual((await a(url, "DELETE", {})).dados.metas, []);
});

test("perfil, sessão e remoção da conta", async t => {
  const app = await iniciar(":memory:");
  t.after(app.fechar);
  const chamar = cliente(app.base);
  assert.equal((await chamar("metas", "POST", { titulo: "Estudar", alvo: 2 })).status, 401);
  assert.equal((await chamar("cadastro", "POST", { ...conta, email: "incorreto" })).status, 422);
  await chamar("cadastro", "POST", conta);
  assert.equal((await chamar("perfil", "PATCH", { nome: "Lua" })).dados.perfil.nome, "Lua");
  await chamar("sair", "POST", {});
  assert.equal((await chamar("estado")).dados.perfil, null);
  assert.equal((await chamar("entrar", "POST", { ...conta, senha: "outra-senha" })).status, 401);
  assert.equal((await chamar("entrar", "POST", conta)).dados.perfil.nome, "Lua");
  assert.equal((await chamar("perfil", "DELETE", {})).status, 200);
  assert.equal((await chamar("entrar", "POST", conta)).status, 401);
});
