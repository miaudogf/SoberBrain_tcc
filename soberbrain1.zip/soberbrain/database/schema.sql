PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY,
  nome TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  sal TEXT NOT NULL,
  senha_hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessoes (
  token_hash TEXT PRIMARY KEY,
  usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  expira_em INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS registros (
  id INTEGER PRIMARY KEY,
  usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  data TEXT NOT NULL,
  humor TEXT NOT NULL CHECK (humor IN ('muito-mal','mal','neutro','bem','muito-bem')),
  nota TEXT NOT NULL DEFAULT '',
  UNIQUE (usuario_id, data)
);
CREATE TABLE IF NOT EXISTS registros_consumo (
  registro_id INTEGER PRIMARY KEY REFERENCES registros(id) ON DELETE CASCADE,
  situacao TEXT NOT NULL CHECK (situacao IN ('nao','vontade','sim')),
  substancia TEXT NOT NULL DEFAULT '',
  quantidade TEXT NOT NULL DEFAULT '',
  contexto TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS atividades (
  id TEXT PRIMARY KEY
);
INSERT OR IGNORE INTO atividades (id) VALUES ('exercicio'), ('estudo'), ('trabalho'),
  ('descanso'), ('companhia'), ('ansiedade'), ('conflito');
CREATE TABLE IF NOT EXISTS registro_atividades (
  registro_id INTEGER NOT NULL REFERENCES registros(id) ON DELETE CASCADE,
  atividade_id TEXT NOT NULL REFERENCES atividades(id),
  PRIMARY KEY (registro_id, atividade_id)
);
CREATE TABLE IF NOT EXISTS metas (
  id TEXT PRIMARY KEY,
  usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  titulo TEXT NOT NULL,
  alvo INTEGER NOT NULL CHECK (alvo BETWEEN 1 AND 365),
  progresso INTEGER NOT NULL DEFAULT 0 CHECK (progresso BETWEEN 0 AND alvo)
);
CREATE INDEX IF NOT EXISTS idx_metas_usuario ON metas(usuario_id);
CREATE INDEX IF NOT EXISTS idx_sessoes_expiracao ON sessoes(expira_em);
