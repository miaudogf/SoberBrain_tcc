# SoberBrain

Diário de humor, hábitos e metas desenvolvido para o Projeto Integrador de Conclusão de Curso de Desenvolvimento de Sistemas da PROZ Educação, turma 251BTTDS. A Home segue o protótipo fornecido pelo grupo. O usuário escolhe uma carinha, pode acrescentar detalhes ao dia e revisitar os registros no calendário.

## Executar

**Projeto integrado.** Use Node.js 24 ou superior. Na pasta que contém este README e o arquivo `package.json`, execute o comando abaixo.

```sh
npm start
```

Abra **http://localhost:3000** no navegador. O servidor cria as tabelas na primeira execução. O projeto usa os módulos nativos do Node.js e dispensa a instalação de pacotes. Para testar a integração, abra **Meu perfil → Criar conta**. Depois de salvar um registro nessa conta, você pode sair, entrar novamente e consultá-lo no calendário. Para encerrar o servidor, pressione **Ctrl+C**.

**Demonstração do front-end.** Abra `frontend/index.html` em um navegador atual para usar a Home, o diário, o calendário, as metas e o perfil de visitante. As imagens, o CSS e o JavaScript estão incluídos no projeto. Os registros de visitante ficam na sessão da aba. O cadastro e o login usam o servidor iniciado pelo comando acima.

## Onde editar

| Caminho | Conteúdo |
| --- | --- |
| `frontend/index.html` | HTML semântico das cinco telas, formulários, navegação e rodapé |
| `frontend/css/base.css` | Paleta, tipografia, cabeçalho, rodapé e controles compartilhados |
| `frontend/css/home.css` | Composição da Home, mascote, botão ilustrado e cartões |
| `frontend/css/telas.css` | Diário, calendário, estatísticas, metas e perfil |
| `frontend/js/` | Eventos, navegação, validação, acesso à API e atualização das telas |
| `frontend/assets/img/` | Mascote, símbolo da marca, botão e cinco arquivos de humor |
| `backend/` | Servidor HTTP, rotas da API e operações de persistência |
| `database/schema.sql` | Criação das tabelas, chaves, vínculos e atividades disponíveis |
| `docs/` | Arquitetura, modelo relacional e referências visuais |
| `tests/` | Testes executáveis do projeto |
| `package.json` e `.gitignore` | Comandos do projeto e exclusões para o Git |

## O que cada tela faz

| Tela | Ação |
| --- | --- |
| Home | Salva o humor de hoje com um toque. Se o dia já tiver uma reflexão, a mudança de carinha preserva o texto e as atividades. |
| Diário | Cria, edita ou exclui um registro por data. Humor e data são obrigatórios. Consumo, contexto, atividades e reflexão são opcionais. |
| Calendário | Mostra as carinhas nos dias registrados. Selecionar um dia abre o resumo e o atalho de edição. As barras contam os humores do mês exibido. |
| Metas | Cria objetivos com uma quantidade de passos, soma avanços, edita o objetivo e permite excluí-lo. |
| Perfil | Personaliza a saudação, abre uma conta, inicia ou encerra a sessão e permite excluir os próprios dados. |

O nome inicial **Eduardo** vem do protótipo e pode ser trocado no perfil. Os três cartões da referência ganharam o histórico da semana, o último registro e a meta em andamento. O texto do botão pêssego usa tinta escura para facilitar a leitura. Os ícones sociais reproduzem o rodapé do anexo. A equipe ainda precisa informar os endereços dos perfis para transformá-los em links.

## Artes selecionadas dos anexos

| Origem | Arquivo no projeto | Uso |
| --- | --- | --- |
| `Home(2).png` | `docs/prototipos/home.png` | Referência para comparar a implementação |
| `humores.png` | `docs/prototipos/humores.png` | Faixa original com as cinco expressões |
| `humores.png` | `frontend/assets/img/humores/` | Cinco PNGs individuais listados abaixo |
| `Karen em Pose Relaxada com Fumaça.png` | `frontend/assets/img/karen.webp` | Mascote espelhada pelo CSS, na mesma direção da Home |
| `Botão pêssego orgânico com contorno marrom.png` | `frontend/assets/img/botao-pessego.webp` | Fundo do botão “Conte do seu dia” |
| `Logotipo Soberbrain em preto e branco.png` | `frontend/assets/img/marca-clara.png` | Símbolo para o cabeçalho claro |
| `Logo Soberbrain invertido com mascote.png` | `frontend/assets/img/marca-escura.png` | Símbolo para o rodapé escuro |

Os arquivos da última imagem seguem esta ordem, da esquerda para a direita.

| Muito mal | Mal | Neutro | Bem | Muito bem |
| --- | --- | --- | --- | --- |
| ![Muito mal](frontend/assets/img/humores/muito-mal.png) | ![Mal](frontend/assets/img/humores/mal.png) | ![Neutro](frontend/assets/img/humores/neutro.png) | ![Bem](frontend/assets/img/humores/bem.png) | ![Muito bem](frontend/assets/img/humores/muito-bem.png) |
| `muito-mal.png` | `mal.png` | `neutro.png` | `bem.png` | `muito-bem.png` |

## Testes e GitHub

```sh
npm test
```

A suíte usa bases temporárias e sessões de teste. O banco criado durante o uso fica em `backend/dados/soberbrain.sqlite`. O `.gitignore` exclui esse diretório, arquivos de ambiente e outros bancos locais.

Para um repositório existente, copie o conteúdo desta pasta para o checkout do grupo. Em um diretório que ainda não usa Git, inicie o histórico com os comandos abaixo. Registre os próximos ajustes em commits correspondentes ao trabalho realizado.

```sh
git init -b main
git add .
git commit -m "Implementa o diário, o calendário e as metas do SoberBrain"
```

A arquitetura, o DER e o roteiro de demonstração estão no [guia técnico](docs/arquitetura.md).
