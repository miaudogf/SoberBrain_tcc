# Arquitetura do SoberBrain

## Fluxo dos registros

Ao escolher **Bem** na Home de uma conta, o navegador envia a data e o humor à API com `fetch`. A API identifica o usuário pela sessão, valida os valores e grava o dia no SQLite. A resposta contém o estado atualizado da conta. A semana, o diário e o calendário usam esses mesmos registros.

O modo visitante mantém o mesmo formato de dados na sessão da aba. Entrar em uma conta abre o diário daquela conta. Ao sair, o visitante recupera o diário que deixou na aba. A passagem de um modo para o outro preserva a separação entre os dois conjuntos de registros.

## Front-end

O HTML mantém os formulários e os títulos das cinco seções. A navegação por fragmentos, como `#diario/2026-11-18`, funciona com os botões Voltar e Avançar do navegador. O CSS reorganiza o cabeçalho, a personagem e as colunas em celulares. Cada humor tem um rótulo textual e cada campo tem um rótulo associado.

| Arquivo em `frontend/js/` | Responsabilidade |
| --- | --- |
| `modelo.js` | Define os cinco humores, as atividades e as regras de entrada usadas no navegador e no servidor |
| `servico.js` | Lê e altera os dados na API ou na sessão de visitante |
| `interface.js` | Formata datas, cria elementos de texto e apresenta confirmações e mensagens |
| `app.js` | Coordena a navegação, a Home e o rodapé |
| `diario.js` | Carrega um dia, lê o formulário e permite editar ou excluir o registro |
| `calendario.js` | Monta os dias do mês, o detalhe da data e as estatísticas |
| `metas-perfil.js` | Controla os objetivos acumulativos, preferências de nome e acesso à conta |

O calendário usa datas civis no formato `AAAA-MM-DD`. O dia atual é calculado no fuso de São Paulo tanto no navegador quanto no servidor. Cada pessoa pode ter um registro por data. O botão da Home altera somente o humor. Salvar o formulário do diário atualiza o conjunto completo daquele dia em uma transação.

## Banco relacional

```mermaid
erDiagram
    USUARIOS ||--o{ SESSOES : possui
    USUARIOS ||--o{ METAS : define
    USUARIOS ||--o{ REGISTROS : escreve
    REGISTROS ||--o| REGISTROS_CONSUMO : detalha
    REGISTROS ||--o{ REGISTRO_ATIVIDADES : inclui
    ATIVIDADES ||--o{ REGISTRO_ATIVIDADES : classifica
```

| Tabela | Chave e regra principal |
| --- | --- |
| `usuarios` | `id` identifica a conta. O e-mail é único. |
| `sessoes` | `token_hash` é a chave primária. `usuario_id` vincula a sessão à conta. |
| `registros` | `id` identifica o registro. O par `usuario_id, data` é único. |
| `registros_consumo` | `registro_id` é chave primária e estrangeira. Pular a pergunta deixa o registro sem uma linha de consumo. |
| `atividades` | `id` identifica cada opção de atividade ou contexto. |
| `registro_atividades` | O par `registro_id, atividade_id` relaciona vários registros a várias atividades. |
| `metas` | `id` identifica a meta. `usuario_id` define quem pode alterá-la. O progresso vai de zero até o alvo. |

O diagrama do projeto forneceu a base de usuários, registros emocionais e consumo. Nesta implementação, cada resposta de consumo pertence ao dia registrado. O vínculo opcional permite registrar só o humor. As chaves estrangeiras com exclusão em cascata removem os dados dependentes quando se exclui o registro ou a conta. A definição completa está em [schema.sql](../database/schema.sql).

## API

O servidor HTTP entrega os arquivos de `frontend/` e atende as rotas abaixo na mesma origem. As rotas de escrita recebem JSON e o cabeçalho `X-Soberbrain: 1`. As respostas de alteração de registros, metas e nome incluem o perfil e as listas atualizadas.

| Método | Rota | Efeito |
| --- | --- | --- |
| GET | `/api/estado` | Consulta o perfil, os registros e as metas. Um visitante recebe `{"perfil":null}`. |
| POST | `/api/cadastro` | Cria uma conta com `nome`, `email` e `senha` e inicia uma sessão. |
| POST | `/api/entrar` | Abre a sessão com e-mail e senha. |
| POST | `/api/sair` | Encerra a sessão atual. |
| PATCH / DELETE | `/api/perfil` | Altera o nome ou exclui a conta com seus dados. |
| PUT | `/api/registros/AAAA-MM-DD` | Cria ou atualiza o dia completo. |
| PATCH | `/api/registros/AAAA-MM-DD` | Grava o humor e preserva os outros campos do dia. |
| DELETE | `/api/registros/AAAA-MM-DD` | Exclui o registro e os detalhes relacionados. |
| POST | `/api/metas` | Cria uma meta com `titulo` e `alvo`. |
| PUT / DELETE | `/api/metas/ID` | Edita ou exclui uma meta. |
| POST | `/api/metas/ID/avancos` | Soma um passo até atingir o alvo. |

As rotas de conta vinculam cada operação ao usuário da sessão. As consultas ao banco são parametrizadas. A senha é processada com `scrypt` e um sal aleatório por conta. O cookie de sessão é `HttpOnly`, usa `SameSite=Lax` e expira após sete dias. O banco guarda o hash do token de sessão. O servidor retorna mensagens de erro de entrada, sessão e persistência em JSON.

O comando `npm start` atende em `127.0.0.1:3000` por padrão. A variável `PORT` muda a porta e `SOBERBRAIN_DB` muda o caminho do banco. Em uma hospedagem com HTTPS, `COOKIE_SEGURO=1` ativa o atributo `Secure` do cookie.

## Demonstração para a banca

1. Inicie o servidor e crie uma conta pelo perfil.
2. Escolha uma carinha na Home, abra **Conte do seu dia**, marque uma atividade e salve uma frase.
3. Troque a carinha na Home e abra o mesmo dia no calendário. Confira a nova expressão, a atividade e a frase original.
4. Crie uma meta de três passos e registre um avanço. A Home passa a mostrar a mesma contagem.
5. Saia e entre novamente. O diário e a meta voltam do SQLite. Edite e exclua um registro para demonstrar o CRUD.

Os testes automatizados podem ser executados com `npm test`. A suíte verifica a gravação, a leitura após reiniciar o servidor, a alteração e a exclusão, as entradas inválidas, a separação dos perfis e o limite de progresso das metas. Um teste adicional exercita o serviço do visitante em modo arquivo e confere a recuperação dos dados na mesma sessão.
